data32={}
for i=1,32 do  
  data32[i]=2^(32-i)  
end  

data64={}
for i=1,64 do  
  data64[i]=2^(64-i)  
end  

function d2b(arg)
	local temp = 0 
	if arg < 0 then
		temp = 2^64 + arg
	else
		temp = arg
	end
    local tr={}  
    for i=1,64 do  
        if temp >= data64[i] then 
          tr[i]=1  
          temp=temp-data64[i]  
        else  
          tr[i]=0  
        end  
    end  
    return tr  
end  

function b2d(arg)  
    local nr=0  
    for i=1,32 do  
        if arg[i] ==1 then  
          nr=nr+2^(32-i)  
        end  
    end  
    return  nr  
end 

function sub(arg)
    local temp = {}
    for i=1,64 do
      temp[i] = arg[i]
    end

    for i=64,1,-1 do
      if temp[i] == 1 then
        temp[i] = 0
        for j=i+1,64 do
          temp[j] = 1
        end
        break
      end
    end

    for i=1,64 do
      if temp[i] == 1 then
        temp[i] = 0
      else
        temp[i] = 1
      end
    end
    return temp
end

local mod = 10000  
  


function marotr(rs, rt, sa)
	local val_rs = getgpr(rs)
	local val_rt = getgpr(rt)
  local val_mult = val_rs * val_rt
  local val_hi = getgpr(33)
  local val_lo = getgpr(34)
  local arr64 = {}
  local arr32_hi = {}
  local arr32_lo = {}
  local temp_hi = {}
  local temp_lo = {}
  print(2147483647*2147483647)
  print(val_rs)
  print(val_rt)
  print(val_mult)

  if val_mult < 0 then
    val_mult = -val_mult
    arr64 = d2b(val_mult)
    arr64 = sub(arr64)
  else
    arr64 = d2b(val_mult)
  end

  for i=1,32 do
    arr32_hi[i] = arr64[i]
  end
  for i=33,64 do
    arr32_lo[i-32] = arr64[i]
  end

  if sa < 1 then    
    val_hi = val_hi + b2d(arr32_hi)
    val_lo = val_lo + b2d(arr32_lo)
  else
    for i=1,sa do
      temp_hi[i] = arr32_hi[32 - sa +i]
      temp_lo[i] = arr32_lo[32 - sa +i]
    end
    for i=sa+1,32 do
      temp_hi[i] = arr32_hi[i - sa]
      temp_lo[i] = arr32_lo[i - sa]
    end
    val_hi = val_hi + b2d(temp_hi)
    val_lo = val_lo + b2d(temp_lo)
  end
	setgpr(33,val_hi)
	setgpr(34,val_lo)
end







register_instruction(
  'marotr $t1,$t2,100',
  'R', -- 相对跳转指令一律用I_BRANCH
  '011100 fffff sssss 00000 ttttt 000000',
  marotr
)