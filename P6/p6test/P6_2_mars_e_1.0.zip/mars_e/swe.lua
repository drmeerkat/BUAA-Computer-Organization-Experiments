



function swe(rt, imm, rs)
	local val_rt = getgpr(rt)
	local val_rs = getgpr(rs)
	local addr = val_rs + imm
	storew(addr,val_rt)

end




register_instruction(
  'swe $t1,-100($t2)',
  'I',
  '011111 ttttt fffff sssssssss 0011111',
  swe
)