# AutoTest
python script for testing verilog CPU automatically 
