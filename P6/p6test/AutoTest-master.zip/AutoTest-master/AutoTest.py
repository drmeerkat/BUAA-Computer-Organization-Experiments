import subprocess
import re
import glob


def Initialize():
    p = subprocess.Popen('cmd.exe', shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    p.stdin.write('{}settings32.bat\n'.format(ISEPath).encode())
    p.stdin.write(b'cd /d' + ProjectPath.encode() + b'\n')
    return p


def Fuse():
    print('Fusing...')
    p = Initialize()
    p.communicate(FuseCode.encode() + b'\n')


def StartSimulation():
    p = Initialize()
    p.stdin.write(SimulationCode.encode() + b'\n')
    return p


def RunSimulation(time):
    p = StartSimulation()
    out, err = p.communicate('run {} ns\n'.format(time * 10).encode())
    return str(out)


def GetAnswer(source):
    p = subprocess.Popen('cmd.exe', shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    out, err = p.communicate(
        'java -jar {} 500000 dump .text HexText {}code.txt db mc CompactDataAtZero {}\n'.format(MarsPath, ProjectPath,
                                                                                                source).encode(),
        timeout=5)
    p.wait()
    return str(out)


def Compare(output, expected):
    error = False
    for i in range(min(len(output), len(expected))):
        if output[i] != expected[i]:
            print('error at line', i + 1)
            print('output {}  while {} expected'.format(output[i], expected[i]))
            error = True
    if len(output) != len(expected):
        print('Wrong output length!')
        error = True
    return error


#需要修改的变量
ProjectPath = 'E:\\Study\\ComputerOrganization\\P6\\'
ISEPath = 'D:\\ISE\\14.7\\ISE_DS\\'
MarsPath = 'E:\\Study\\ComputerOrganization\\Mars.jar'
testbenchName = 'tb'
TestPath = 'E:\\PycharmProjects\\test\\test\\'


FuseCode = 'fuse -intstyle ise -incremental -lib unisims_ver -lib unimacro_ver -lib xilinxcorelib_ver -lib secureip -o tb_isim_beh.exe -prj {}_beh.prj work.{} work.glbl'.format(
    testbenchName, testbenchName)
SimulationCode = 'tb_isim_beh.exe -intstyle ise -wdb tb_isim_beh.wdb'
OutPutPattern = re.compile(
    '\$[ 12a-zA-Z][ \da-zA-Z] <= [\da-zA-Z]{8}|\$31 <= [\da-zA-Z]{8}|\*[\da-zA-Z]{8} <= [\da-zA-Z]{8}')
Fuse()

for fileName in glob.glob(TestPath + '\\*.asm'):
    print(fileName)
    expected = OutPutPattern.findall(GetAnswer(fileName))
    print('Simulating...')
    output = OutPutPattern.findall(RunSimulation(30000))
    print('Test', fileName)
    print('Output:  ', output)
    print('Expected:', expected)
    if Compare(output, expected):
        print('WA')
    else:
        print('AC')
